﻿param([string]$LastImportDate)
$SSISDate = $LastImportDate



[string]$SSISDate="2019-09-01"
Write-Host("https://api.opencovid.ca/timeseries?stat=all&geo=pt&pt_names=canonical&after=$SSISDate")
$data= Invoke-RestMethod -uri "https://api.opencovid.ca/timeseries?stat=all&geo=pt&pt_names=canonical&after=$SSISDate"   



$data.data.cases | export-csv -path C:\Users\maryb\Desktop\Assignment2\Cases.csv –NoTypeInformation
$data.data.deaths | export-csv -path C:\Users\maryb\Desktop\Assignment2\Mortality.csv –NoTypeInformation
$data.data.icu | export-csv -path C:\Users\maryb\Desktop\Assignment2\ActiveCases.csv –NoTypeInformation
$data.data.hospitalizations | export-csv -path C:\Users\maryb\Desktop\Assignment2\RecoveredCases.csv –NoTypeInformation
$data.data.tests_completed | export-csv -path C:\Users\maryb\Desktop\Assignment2\Testing.csv –NoTypeInformation
$data.data.vaccine_coverage_dose_3 | export-csv -path C:\Users\maryb\Desktop\Assignment2\FullyVaccinated.csv –NoTypeInformation