﻿param([string]$LastImportDate)
$SSISDate = $LastImportDate

$data= Invoke-RestMethod -uri "https://api.opencovid.ca/timeseries?stat=all&geo=pt&pt_names=canonical"   

$data.data.cases | Select-Object name, region, date, value, value_daily | where {$_.date -ge $SSISDate} | export-csv -path C:\Users\maryb\Desktop\Assignment2\Cases.csv –NoTypeInformation
$data.data.deaths | Select-Object name, region, date, value, value_daily | where {$_.date -ge $SSISDate} | export-csv -path C:\Users\maryb\Desktop\Assignment2\Mortality.csv –NoTypeInformation
$data.data.icu | Select-Object name, region, date, value, value_daily | where {$_.date -ge $SSISDate} | export-csv -path C:\Users\maryb\Desktop\Assignment2\ActiveCases.csv –NoTypeInformation
$data.data.hospitalizations | Select-Object name, region, date, value, value_daily | where {$_.date -ge $SSISDate} | export-csv -path C:\Users\maryb\Desktop\Assignment2\Recovered.csv –NoTypeInformation
$data.data.tests_completed | Select-Object name, region, date, value, value_daily | where {$_.date -ge $SSISDate} | export-csv -path C:\Users\maryb\Desktop\Assignment2\Testing.csv –NoTypeInformation
$data.data.vaccine_coverage_dose_3 | Select-Object name, region, date, value, value_daily | where {$_.date -ge $SSISDate} | export-csv -path C:\Users\maryb\Desktop\Assignment2\FullyVaccinated.csv –NoTypeInforma