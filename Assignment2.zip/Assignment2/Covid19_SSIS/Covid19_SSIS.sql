-- Author : Mary Bello
--Date: 2022/11/25
-- Description: Create database Covid19_SSIS

If not exists (Select * from sys.databases where name = 'Covid19_SSIS')
Begin
		Create database Covid19_SSIS;
End;
go

-- Create table Cases
Use Covid19_SSIS;
go

create table Covid19_SSIS.dbo.Cases (
		Region Varchar(13) not null,
		Date_Report date not null,
		Cases bigint,
		Cumulative_Case bigint,
		Cases_Month Varchar(15),
Constraint CK_Cases_Region_Date_Report Primary Key (Region, Date_Report));

-- Create table ActiveCases

create table Covid19_SSIS.dbo.ActiveCases (
		Region Varchar(13) not null,
		Date_Report date not null,
		Cases bigint,
		Cumulative_Case bigint,
		Cases_Month Varchar(15),
Constraint CK_ActiveCases_Region_Date Primary Key (Region, Date_Report));


-- Create table Mortality
create table Covid19_SSIS.dbo.Mortality (
		Region Varchar(13) not null,
		Date_Report date not null,
		Cases bigint,
		Cumulative_Case bigint,
		Cases_Month Varchar(15),
Constraint CK_Mortality_Region_Date Primary Key (Region, Date_Report));


-- Create table RecoveredCases

create table Covid19_SSIS.dbo.RecoveredCases (
		Region Varchar(13) not null,
		Date_Report date not null,
		Cases bigint,
		Cumulative_Case bigint,
		Cases_Month Varchar(15),
Constraint CK_RecoveredCases_Region_Date Primary Key (Region, Date_Report));

-- Create table RecoveredCases

create table Covid19_SSIS.dbo.Testing (
		Region Varchar(13) not null,
		Date_Report date not null,
		Cases bigint,
		Cumulative_Case bigint,
		Cases_Month Varchar(15),
Constraint CK_Testing_Region_Date Primary Key (Region, Date_Report));

-- Create table FullyVaccinated

create table Covid19_SSIS.dbo.FullyVaccinated (
		Region Varchar(13) not null,
		Date_Report date not null,
		Cases bigint,
		Cumulative_Case bigint,
		Cases_Month Varchar(15),
Constraint CK_Cases_Region_Date Primary Key (Region, Date_Report));