/****** Script for SelectTopNRows command from SSMS  ******/
SELECT TOP (1000) [Region]
      ,[Date_Report]
      ,[Cases]
      ,[Cumulative_Case]
      ,[Cases_Month]
  FROM [Covid19_SSIS].[dbo].[Cases]

  select (year([Date_Report])) as [Year], (cases_month) as [Month], (Sum(Cases)) as Total_Cases from Cases
  where Cases_Month = 'Jan'
  group by Cases_Month, year(Date_Report)
  order by year([Date_Report])